package tp.pr5.testprofesor;

import tp.pr5.City;
import tp.pr5.Street;

public class MockCity extends City {

	public MockCity(Street[] cityMap) {
		super(cityMap);
	}

	public MockCity() {
		// TODO Auto-generated constructor stub
	}

}
